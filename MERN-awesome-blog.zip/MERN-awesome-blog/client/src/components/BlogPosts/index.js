import BlogPosts from "./BlogPosts";
export default BlogPosts;
