import { combineReducers } from "redux";

import posts from "./blogPosts";

export const reducers = combineReducers({ posts });
