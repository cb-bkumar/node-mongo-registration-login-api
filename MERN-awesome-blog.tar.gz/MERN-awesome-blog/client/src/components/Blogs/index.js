import Blogs from "./Blogs";
export default Blogs;
